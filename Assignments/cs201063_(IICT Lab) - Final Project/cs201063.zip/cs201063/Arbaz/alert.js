function addToCart() {
    alert("Added to Cart.!");
    location.href = "../orderForm.html";
}