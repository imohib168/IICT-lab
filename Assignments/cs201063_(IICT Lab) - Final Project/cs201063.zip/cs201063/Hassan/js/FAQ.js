function emailus() {
	var email = prompt("Enter your Email");
	alert("We have sent you the details on" + "\n" + email + "\n" + "Kindly, check your email.");
}