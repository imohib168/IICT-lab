function abc() {
    alert("Added to cart..!");
    location.href = "../../orderForm.html";
}